struct header_contents
{
    
    unsigned short source_port;
    unsigned short destination_port;
    unsigned long sequence_number;
    unsigned long acknowledgement_number;
    unsigned short doff_res_control;
    
    //char * data_offset; [4 bits]
    unsigned short data_offset;
    //char * reserved; [6 bits]
    unsigned short reserved;
    //char * control_bits; [6 bits]
    unsigned short control_bits;
    
    //URG [1 bit]
    unsigned char URG;
    //ACK [1 bit]
    unsigned char ACK;
    //PSH [1 bit]
    unsigned char PSH;
    //RST [1 bit]
    unsigned char RST;
    //SYN [1 bit]
    unsigned char SYN;
    //FIN [1 bit]
    unsigned char FIN;
    
    unsigned short window;
    unsigned short checksum;
    unsigned short urgent_pointer;
    
};
