/*
 *
 *
 *
 */
#import <stdio.h>
#import <stdlib.h>
#import <string.h>
#import "header.h"

#define TRUE 1
#define FALSE 0
#define ERROR -1
//#define TEST //TODO REMOVE

int printheader();
int changes();
int readfile(char []);
int writefile(char []);

struct header_contents * header = NULL;

int main()
{
    char filename[] = "test.bin";
    printf("filename: %s\n", filename); //TODO REMOVE
    
    //read the bin file
    printf("\nStatus of readfile: %d\n\n", readfile(filename)); //TODO REMOVE PRINTF
    
    printf("\n[ORIGINAL]\n");
    //print header info
    printheader();
    
    //switch the source and destination fields HERE (or in another function)
    changes();
    
    printf("\n[MODIFIED]\n");
    //print header info again
    printheader();
    
    //write the bin file
    printf("\nStatus of writefile: %d\n\n", writefile(filename)); //TODO REMOVE PRINTF
    
}

int printheader()
{
    printf("Source Port: %u\n", (header->source_port));
    printf("Destination Port: %u\n", (header->destination_port));
    printf("Sequence Number: %lu\n", (header->sequence_number));
    printf("Acknowledgement Number: %lu\n", (header->acknowledgement_number));
    //will need to split these into separate fields later
    //printf("Data Offset/Reserved/Control Bits (Int Value): %u\n", (header->doff_res_control));
    printf("Data Offset: %u\n", (header->data_offset));
    printf("Reserved: %u\n", (header->reserved));
    printf("Control Bits:\n");
    printf("\tURG: %u\n", (header->URG));
    printf("\tACK: %u\n", (header->ACK));
    printf("\tPSH: %u\n", (header->PSH));
    printf("\tRST: %u\n", (header->RST));
    printf("\tSYN: %u\n", (header->SYN));
    printf("\tFIN: %u\n", (header->FIN));
    printf("Window: %u\n", (header->window));
    printf("Checksum: %u\n", (header->checksum));
    printf("Urgent Pointer: %u\n", (header->urgent_pointer));
    return TRUE;
}

int changes()
{
    unsigned short buffer1 = header->source_port;
    header->source_port = header->destination_port;
    header->destination_port = buffer1;
    
    header->acknowledgement_number = header->sequence_number;
    header->sequence_number++;
    
    if(header->SYN == TRUE)
    {
        header->ACK = TRUE;
    }
    
    header->reserved = 0;
    header->data_offset = 20;
    header->window = 0;
    header->checksum = 65535;
    header->urgent_pointer = 0;
    
    return ERROR;
}

int readfile(char filename[])
{
    
    FILE * file = fopen(filename, "r");
    int returnval = 0;
    
    //check if such a file exists
    if (file == NULL)
    {
        returnval = ERROR;
    }
    else
    {
        unsigned char header_file_input[20];
        
        fread(header_file_input, 1, 20, file);
        
        header = (struct header_contents *) malloc(sizeof(struct header_contents));
        
        header->source_port = header_file_input[0];
        header->source_port = header->source_port << 8;
        header->source_port = header->source_port | header_file_input[1];
        
        header->destination_port = header_file_input[2];
        header->destination_port = header->destination_port << 8;
        header->destination_port = header->destination_port | header_file_input[3];
        
        header->sequence_number = header_file_input[4];
        header->sequence_number = header->sequence_number << 8;
        header->sequence_number = header->sequence_number | header_file_input[5];
        header->sequence_number = header->sequence_number << 8;
        header->sequence_number = header->sequence_number | header_file_input[6];
        header->sequence_number = header->sequence_number << 8;
        header->sequence_number = header->sequence_number | header_file_input[7];
        
        header->acknowledgement_number = header_file_input[8];
        header->acknowledgement_number = header->acknowledgement_number << 8;
        header->acknowledgement_number = header->acknowledgement_number | header_file_input[9];
        header->acknowledgement_number = header->acknowledgement_number << 8;
        header->acknowledgement_number = header->acknowledgement_number | header_file_input[10];
        header->acknowledgement_number = header->acknowledgement_number << 8;
        header->acknowledgement_number = header->acknowledgement_number | header_file_input[11];
        
        //will need to split these into separate fields later
        header->doff_res_control = header_file_input[12];
        header->doff_res_control = header->doff_res_control << 8;
        header->doff_res_control = header->doff_res_control | header_file_input[13];
        
        //char * data_offset; [4 bits] WORKS
        header->data_offset = header->doff_res_control;
        unsigned short data_offset_mask = 61440;
        printf("data_offset_mask: %u\n", data_offset_mask); //TODO REMOVE
        header->data_offset = header->data_offset & data_offset_mask;
        header->data_offset = header->data_offset >> 12;
        
        //char * reserved; [6 bits] WORKS
        header->reserved = header->doff_res_control;
        unsigned short reserved_mask = 4032;
        printf("reserved_mask: %u\n", reserved_mask); //TODO REMOVE
        header->reserved = header->reserved & reserved_mask;
        header->reserved = header->reserved >> 6;
        
        //char * control_bits; [6 bits] WORKS
        header->control_bits = header->doff_res_control;
        unsigned short control_bits_mask = 63;
        printf("reserved_mask: %u\n", control_bits_mask); //TODO REMOVE
        header->control_bits = header->control_bits & control_bits_mask;
        
        //URG 00100000
        header->URG = header->control_bits;
        header->URG = header->URG & 32;
        header->URG = header->URG >> 5;
        //ACK 00010000
        header->ACK = header->control_bits;
        header->ACK = header->ACK & 16;
        header->ACK = header->ACK >> 4;
        //PSH 00001000
        header->PSH = header->control_bits;
        header->PSH = header->PSH & 8;
        header->PSH = header->PSH >> 3;
        //RST 00000100
        header->RST = header->control_bits;
        header->RST = header->RST & 4;
        header->RST = header->RST >> 2;
        //SYN 00000010
        header->SYN = header->control_bits;
        header->SYN = header->SYN & 2;
        header->SYN = header->SYN >> 1;
        //FIN 00000001
        header->FIN = header->control_bits;
        header->FIN = header->FIN & 1;
        
        header->window = header_file_input[14];
        header->window = header->window << 8;
        header->window = header->window | header_file_input[15];
        
        header->checksum = header_file_input[16];
        header->checksum = header->checksum << 8;
        header->checksum = header->checksum | header_file_input[17];
        
        header->urgent_pointer = header_file_input[18];
        header->urgent_pointer = header->urgent_pointer << 8;
        header->urgent_pointer = header->urgent_pointer | header_file_input[19];
        
        returnval = TRUE;
        fclose(file);
    }
    
    return returnval;
}

int writefile(char filename[])
{
    unsigned char header_file_output[20];
    
    //header_file_output[0] = (header->source_port | 65280) >> 8;
    //header_file_output[1] = (header->source_port | 255);
    
    header_file_output[0] = (header->source_port & 65280) >> 8;
    header_file_output[1] = (header->source_port & 255);
    
    printf("BYTES:\n");
    int i = 0;
    while(i < 20)
    {
        printf("%u\n", header_file_output[i]);
        i++;
    }
    
    printf("ERROR: writefile not yet implemented\n"); //TODO REMOVE
    return ERROR;
}